package state;

import java.awt.*;

public class GameState extends  State {
    public GameState() {

    }

    @Override
    public void update() {

    }

    @Override
    public void render(Graphics g) {

    }
}
